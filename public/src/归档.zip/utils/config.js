/*
    初始化配置参数
    create by chenzhaofei on 2020/04/30
*/
export class Config{
    constructor(){
        this.defaultOptions = {
            stun:['stun1.l.google.com:19302','stun2.l.google.com:19302','stun3.l.google.com:19302','stun4.l.google.com:19302']
        };
        this.map = new WeakMap();
    }
    static getInstance(){
        if(!Config.instance){
            Config.instance = new Config();
        }
        return Config.instance;
    }
    getVideoArea(){
        if(!window){
            return null;
        }
        if(window.document.getElementById('userVideo')){
            return window.document.getElementById('userVideo');
        }
        if(window.document.getElementById('app')){
            return window.document.getElementById('app');
        }
        return null;
    }
    initParams(options){
        this.options = Object.assign(this.defaultOptions,options||{});
    }
    getParams(key){
        if(this.options.hasOwnProperty(key)){
            return this.options['key'];
        }
        return null;
    }
    setParam(key,value){
        this.options[key] = value;
    }
}