export const RTC = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;
export const SDP = window.RTCSessionDescription || window.mozRTCSessionDescription || window.webkitRTCSessionDescription;
/**
 * 支持程度：
 */
const UserMedia  = navigator.getUserMedia?navigator.getUserMedia:
                   navigator.mozGetUserMedia?navigator.mozGetUserMedia:
                   navigator.webkitGetUserMedia?navigator.webkitGetUserMedia:null;
const MediaDevices = navigator.mediaDevices?navigator.mediaDevices:
                    navigator.mozMediaDevices?navigator.mozMediaDevices:
                    navigator.webkitMediaDevices?navigator.webkitMediaDevices:null;

export default class ProcessEnv{
    constructor(){
        if(ProcessEnv.instance){
            throw new Error('Instance has exit,please use getInstance!');
        }
        this.options={
            ws:'ws://localhost:5001',
            RTC,
            SDP,
            UserMedia,
            MediaDevices
        }
    }
    static getInstance(){
        if(!ProcessEnv.instance){
            ProcessEnv.instance = new ProcessEnv()
        }
        return ProcessEnv.instance;
    }
    get isSupport(){
        return !!RTC && !!SDP && (!!UserMedia||!!MediaDevices);
    }
    get socketUrl(){
        return this.options.ws;
    }
    getAPI(name){
        return this.options[name];
    }
    getVersion(ua,exp,pos){
        const match = ua.match(exp);
        return match && match.length >= pos && parseInt(match[pos],10);
    }
    detectBroswer(window){
        const {navigator} = window;
        const result =  {browser:null,version:null};

        if(typeof window === 'undefined' || !navigator){
            result.browser = 'Not a broswer.'
            return result;
        }
        if(navigator.mozGetUserMedia){//FireFox
            result.browser = 'firefox';
            result.version = this.getVersion(navigator.userAgent,/Firefox\/(\d+)\./,1);
        }else if(navigator.webkitGetUserMedia 
            || (window.isSecureContext === false && window.webkitRTCPeerConnection && !window.RTCIceGather)){
            //Chrome,chromium,webview,Opera.
            result.browser = 'chrome';
            result.version =  this.getVersion(navigator.userAgent,
                /Chrom[e|ium]\/(\d+)\./,1);
        }else if(navigator.MediaDevices
            && navigator.userAgent.match(/Edge\/(\d+).(\d+)$/))
        {//Edge
            result.browser = 'edge';
            result.version =  this.getVersion(navigator.userAgent,/Edge\/(\d+).(\d+)$/,2);
        }else if(window.RTCPeerConnection 
                && navigator.userAgent.match(/AppleWebKit\/(\d+)\./)
        ){//Safari
            result.browser = 'safari';
            result.version = this.getVersion(navigator.userAgent,/AppleWebKit\/(\d+)\./,1);

         }else{
            result.browser = 'Not a supported broswer.';
        }
        return result;
    }
    getRandomId(){
        const time = new Date().getTime();
        return `uid-${time}-${(Math.random()*1000000).toFixed(0)}-${(Math.random()*1000000).toFixed(0)}`
    }
}