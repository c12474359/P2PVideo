export default class LogProxy{
    constructor(options){
        if(LogProxy.instance){
            throw new Error('This is a Singlon,Instance has exit please use getInstance!')
        }
        this.defaultOptions = {
            level:15,
            TRACE:8,
            INFO:4,
            WARN:2,
            ERROR:1
        }
        this.options = Object.assign(this.defaultOptions,options||{});
    }
    static getInstance(){
        if(!LogProxy.instance){
            LogProxy.instance = new LogProxy();
        }
        return LogProxy.instance;
    }
    trace(...rest){
        if((this.options.level & this.defaultOptions.TRACE) >> 3 === 1){
            console.log(...rest)
        }
    }
    info(...rest){
        if((this.options.level & this.defaultOptions.INFO) >> 2 === 1){
            console.log(...rest)
        }
    }
    warn(...rest){
        if((this.options.level & this.defaultOptions.WARN) >> 1 === 1){
            console.log(...rest)
        }
    }
    error(...rest){
        if((this.options.level & this.defaultOptions.ERROR) === 1){
            console.log(...rest)
        }
    }
}