const aa = new Set([1,2,3,4]);
const bb = new Set([2,3,4,5]);
const cc =  new Set([...aa,...bb]);
console.log(cc);