import env from '../utils/env';
import Room from './room';
import Session from '../webrtc/session'
import dep from '../utils/dep'

export default class Manager{
    constructor(options){
        this.id = env.getInstance().getRandomId();
        this.defaultOptions = {
            sessionId:null
        }
        this.options = Object.assign({},this.defaultOptions,options||{});
        this.dep = dep.getInstance();
        this.session = null;
        this.room = null;
        this.init();
    }
    init(){
        //创建session
        const options = Object.assign({},this.options,{id:this.id,parent:this});
        this.dep.on('onopen',()=>{this.enterRoom()});
        this.session = new Session(options);
    }
    enterRoom(){
        const id = this.id;
        this.room = new Room({...this.options,id});
    }
    closeRoom(params){
        const own = this.params.id;
    }
}