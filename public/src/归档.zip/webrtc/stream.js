import {Config} from '../utils/config';
import Env from '../utils/env.js';
import Log from '../utils/logproxy';
import UserMedia from './usermedia';

export default class LocalStream{
    constructor(options){
        this.config = Config.getInstance();
        this.env = Env.getInstance();
        this.log = Log.getInstance();
        this.name = this.__proto__.constructor.name;
        this.defaultOptions={
            type:'local',
            id:null,
            window:null
        };
        this.options = Object.assign({},this.defaultOptions,options||{});
        //创建视频
        this.init();
    }
    init(){
        if(!!this.env.isSupport === void 0){
            this.log.warn('该浏览器对于视频直播支持上存在问题，请检查！');
            return;
        }
        const broswerInfo = this.env.detectBroswer(window);
        this.log.info('浏览器信息：',broswerInfo);
        //创建本地流读取对象
        this.userMedia = new UserMedia(window); 
    }
    /**
     * 
     * @param {*} options 
     */
    async getUserMedia(){
        this.options.streamType = 'desktop';
        const userStream = await this.userMedia.getUserMedia({
            video:
            {
                width:1024,
                heigth:728
            },
            audio:true
        });
        return userStream;
    }
    async getDesktop(){
        const screenStream = this.userMedia.getDisplayMedia({
            video:
            {
                width:1024,
                heigth:728
            },
            audio:true
        })
        return screenStream;
    }
    close(){
        this.log.info(`steam::close->关闭视频，type(${this.options.streamType})`)
        if(this.userStream){
            this.userStream = null;
        }
        if(this.screenStream){
            this.screenStream = null;
        }
    }
    addEvent(){
        this.peer.onnegotiationneeded = ()=>{
            this.onRTCOpen();
        }
        this.peer.ondatachannel = (evt)=>{
            this.onChannel();
        }
        this.peer.onicecandidate = (evt)=>{
            this.onIceCandidate(evt);
        }
    }
    removeEvent(){
        this.peer.onnegotiationneeded = null;
        this.peer.ondatachannel = null;
        this.peer.onicecandidate = null;
    }
    destroy(){
        this.config = null;
        this.env = null;
        this.log = null;
        this.name = null;
        this.peer = null;
        this.userMedia = null;
        this.defaultOptions=null;
        this.options = null;
    }
}