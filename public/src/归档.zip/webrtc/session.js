import env from '../utils/env'
import log from '../utils/logproxy'
import dep from '../utils/dep'
import Peer from './peer';

export default class Session{
    constructor(options){
        this.defaultOptions = {
        }
        this.env  = env.getInstance();
        this.log = log.getInstance();
        this.dep = dep.getInstance();
        this.name = this.__proto__.constructor.name;
        this.options = Object.assign({},this.defaultOptions,options||{});
        this.guests = null;
        this.peers = new Map();
        this.ws = null;
        this.isOpen = false;
        this.init();
    }
    init(){
        const WebSocket = this.options.window.WebSocket;
        this.ws = new WebSocket(this.env.socketUrl);
        this.ws.onopen = () => this.onOpen();
        this.ws.onerror = () => this.onError();
        this.ws.onmessage = (data) => this.onMessage(data);
        this.ws.onclose = () => this.onClose();
        //peer
        //增加事件
        this.dep.on('peerMessage',(data)=>{this.sendMessage(data)});
        this.dep.on('pushStream',(data)=>{this.pushStream(data)});
        //获取视频
    }
    onOpen(){
        if(this.isOpen) return;
        this.isOpen = true;
        this.dep.emit('onopen');
        //注册信令
        this.sendMessage({type:'register'});
    }
    sendMessage(msg){
        const type = msg.type;
        const data = Object.assign({id:this.options.id,roomid:this.options.roomId},msg.data||{});
        msg.data = data;
        this.ws.send(JSON.stringify(msg));
    }
    onMessage(res){
        const data =  res.data;
        this.dep.emit('onmessage',data);
        const msg = JSON.parse(data);
        if(msg.data.error !== 0){
            this.log.error(`${this.name}::onMessage-> ${msg.type}:${msg.data.message}`);
            return;
        }
        let old;
        switch(msg.type){
            case 'register':
                this.log.trace(`${this.name}::onMessage-> register ${msg.data.message}`);
                //发送信令查询用户
                this.sendMessage({type:'getGuestList'});
                break;
            case 'onGuestList':
                //根据列表创建peer
                old = this.guests || [];
                const ngl = msg.data.list || [];
                this.guests = new Set([...old,...ngl]);
                this.log.trace(`${this.name}::onMessage-> onGuestList ${this.guests.size}`);
                ///去创建peer
                this.guests.forEach(id=>{
                    if(!this.peers.has(id)&&id !== this.options.id){
                        this.createPeer(id)
                    }
                })
                break;
            case 'enter'://有新用户进入房间
                old = this.guests || [];
                this.log.trace(`${this.name}::onMessage->用户（${msg.data.id}）进入`);
                this.guests = new Set([...old,msg.data.id]);
                // this.createPeer(msg.id);
                //去创建
                break;
            case 'exit':
                if(this.guests&&this.guests.delete(msg.data.id)){
                    this.log.trace(`${this.name}::onMessage->用户离开（${msg.data.id}）`);
                    //关闭该peer
                    this.closePeer([msg.data.id]);
                }
                break;
            case 'peerMessage':
                this.onPeerMessage(msg.data);
                break;
            case 'response':
                break;
        }
    }
    onPeerMessage(data){
        let peer;
        switch(data.action){
            case 'connRequest':
                //检查peer是否存在
                peer = this.peers.get(data.id);
                if(!peer){
                    peer = new Peer({
                        remoteid:data.id,
                        id:this.options.id,
                        type:this.options.type,
                        server:1,
                        remoteOffer:data.remoteOffer
                    });
                    this.peers.set(data.id,peer);
                    peer.connect();
                }else{
                    this.log.info(`${this.name}::onPeerMessage::connrequest->重新握手`)
                    peer.options.remoteOffer = data.remoteOffer;
                    peer.createAnswer();
                    break;
                }
                break;
            case 'connResponse':
                peer = this.peers.get(data.id);
                if(peer){
                    if(peer.options.remoteOffer){//证明需要重新握手
                        peer.options.remoteOffer = data.remoteOffer;
                        peer.createOffer()
                    }else{
                         peer.acceptAnswerOrOffer(data);
                    } 
                }
                break;
            case 'ice':
                peer = this.peers.get(data.id);
                if(peer){
                    peer.peer.addIceCandidate(data.ice);
                }
                break;
            case 'reshake':
                peer = this.peers.get(data.id);
                if(peer){
                    peer.createOffer({iceRestart:true});
                }
                break;
        }
    }
    createPeer(id){
        let peer = new Peer({
            remoteid:id,
            id:this.options.id,
            type:this.options.type
        });
        this.peers.set(id,peer);
        peer.connect();
        
    }
    /**
     * 是否符合推流
     */
    pushStream(data){                             
        if(this.options.parent){
            const room = this.options.parent.room;
            const stream = room.getMediaStream;
            const peer = this.peers.get(data.remoteid);
            console.log(stream,peer,this.peers);
            if(stream&&peer){
                peer.addStream(stream);
            }
        }
    }
    pushTrack(data){
        if(this.options.parent){
            const room = this.options.parent.room;
            const stream = room.getMediaStream ? room.getMediaStream.stream ? room.getMediaStream.stream : new MediaStream() : new MediaStream();
            const peer = this.peers.get(data.id);
            if(peer){
                peer.addTrack(stream);
            }
        }
    }
    // /**
    //  * 
    //  * @param {*} ids 
    //  */
    // pushToAll(stream){
    //     //推流
    //     this.guests.forEach(id => {
    //         if(id !== this.options.id){
    //             if(!this.peers.has(id)){
    //                 this.createPeer(id);
    //             }else{
    //                 this.peers.get(id).addStream(stream);
    //             }
    //         }
            
    //     });
    // }
    // closeToAll(stream){
    //     this.guests.forEach(id => {
    //         if(id !== this.options.id){
    //             if(this.peers.has(id)){
    //                 this.peers.get(id).removeStream(stream);
    //             }
    //         }       
    //     });
    // }
    closePeer(ids){
        ids.forEach(id=>{
             const peer = this.peers.get(id);
             if(peer) peer.close();
             this.peers.delete(id);
        })
        console.log(ids,this.peers);
    }
    onError(err){
        this.log.error(`${this.name}::onError-> err:${err.toString()}`);
        this.dep.emit('onerror',this);
    }
    onClose(){
        this.log.trace(`${this.name}::onClose`);
        this.dep.emit('onclose',this);
    }
}